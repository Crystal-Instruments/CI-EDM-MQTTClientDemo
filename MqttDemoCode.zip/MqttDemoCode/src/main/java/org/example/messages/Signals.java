package org.example.messages;

public class Signals {
    public String Timestamp;
    public String Name;
    public String Type;
    public String UnitX;
    public String UnitY;
    public String UnitZ;
    public Long BlockSize;
    public float SamplingRate;
    public String WindowType;
    public String DisplayFormat;
    public Signals(){

    }

}
