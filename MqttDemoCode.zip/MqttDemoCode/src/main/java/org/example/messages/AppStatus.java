package org.example.messages;

public class AppStatus {
    public String Timestamp;
    public String SoftwareMode;
    public String Version;

    public AppStatus(){

    }
}
