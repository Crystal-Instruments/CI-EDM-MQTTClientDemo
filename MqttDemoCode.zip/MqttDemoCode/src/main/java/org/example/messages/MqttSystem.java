package org.example.messages;

import java.util.List;

public class MqttSystem {
    public String Name;
    public List<MqttDeviceModule> Modules;
}
