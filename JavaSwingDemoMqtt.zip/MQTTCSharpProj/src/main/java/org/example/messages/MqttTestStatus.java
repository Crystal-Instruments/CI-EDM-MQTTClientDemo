package org.example.messages;

public class MqttTestStatus {
    public String Timestamp;
    public String Name;
    public String Status;
    public String RunFolder;
    public String MeasureStartAt;
    public MqttTestStatus(){

    }
}
