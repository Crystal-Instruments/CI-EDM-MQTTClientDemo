package org.example.messages;

public class MqttLimitStatus {
    public String Timestamp;
    public String Name;
    public String Status;
    public MqttLimitStatus(){

    }
}
