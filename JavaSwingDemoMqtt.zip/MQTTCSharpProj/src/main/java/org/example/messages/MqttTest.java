package org.example.messages;

public class MqttTest {
    public String Name;
    public String Type;
    public String CreatedTime;

    public MqttTest(){

    }
}
