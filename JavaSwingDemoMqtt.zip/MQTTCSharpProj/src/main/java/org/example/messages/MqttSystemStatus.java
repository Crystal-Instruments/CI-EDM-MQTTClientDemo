package org.example.messages;

public class MqttSystemStatus {
    public String Timestamp;
    public String Name;
    public String Status;
}
