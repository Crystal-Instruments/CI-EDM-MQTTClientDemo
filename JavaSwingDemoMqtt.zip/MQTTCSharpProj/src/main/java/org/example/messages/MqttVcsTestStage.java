package org.example.messages;

public class MqttVcsTestStage {
    public String Timestamp;
    public String Name;
    public String Stage;
    public MqttVcsTestStage(){

    }
}
