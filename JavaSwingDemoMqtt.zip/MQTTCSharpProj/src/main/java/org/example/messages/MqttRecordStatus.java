package org.example.messages;

public class MqttRecordStatus {
    public String Timestamp;
    public String Name;
    public String Status;

    public MqttRecordStatus(){

    }
}
