package org.example.messages;

public class MqttVcsControlFlag {
    public String Timestamp;
    public String Name;
    public String Flag;

    public MqttVcsControlFlag(){

    }
}
