package org.example.messages;

public class MqttDsaTestStatus {
    public String Timestamp;
    public int AcceptedFrameNum;
    public int TotalFrameNum;
    public int AverageNum;
    public double OutputPeak;
    public int DIOStatus;
    public int DisplaySignalCount;
    public int RPM1;
    public int RPM2;
    public MqttDsaTestStatus(){

    }
}
