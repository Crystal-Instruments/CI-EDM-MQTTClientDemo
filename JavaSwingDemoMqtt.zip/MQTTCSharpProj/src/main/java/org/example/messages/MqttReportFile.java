package org.example.messages;

public class MqttReportFile {
    public String ReportName;
    public byte [] ReportContent;
    public MqttReportFile(){

    }
}
