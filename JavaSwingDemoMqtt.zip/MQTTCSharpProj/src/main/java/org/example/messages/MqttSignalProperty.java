package org.example.messages;

public class MqttSignalProperty {
    public String SignalName;
    public String PropertyName;
    public double Value;
    public String Unit;
}
